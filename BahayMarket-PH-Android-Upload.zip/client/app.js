const listings=[
 {id:1,type:"House & Lot",title:"Modern Family Home",location:"San Pablo City, Laguna",price:3850000,bedrooms:3,bathrooms:2,verified:true},
 {id:2,type:"Condo",title:"City Condo Unit",location:"Quezon City, Metro Manila",price:5200000,bedrooms:2,bathrooms:1,verified:true},
 {id:3,type:"Lot",title:"Residential Lot",location:"Calamba, Laguna",price:1800000,bedrooms:0,bathrooms:0,verified:false},
 {id:4,type:"House & Lot",title:"Starter Home",location:"Cabuyao, Laguna",price:2650000,bedrooms:2,bathrooms:1,verified:true},
 {id:5,type:"Commercial",title:"Commercial Property",location:"Batangas City, Batangas",price:8500000,bedrooms:0,bathrooms:2,verified:false},
 {id:6,type:"House & Lot",title:"Spacious Subdivision Home",location:"Antipolo, Rizal",price:6100000,bedrooms:4,bathrooms:3,verified:true}
];

let favorites=JSON.parse(localStorage.getItem("bahayFavorites")||"[]");

function money(n){return "₱"+Number(n).toLocaleString("en-PH")}
function render(data=listings){
 const term=(document.getElementById("search").value||"").toLowerCase();
 const type=document.getElementById("type").value;
 const max=Number(document.getElementById("maxPrice").value||0);
 const filtered=data.filter(x=>
   (!term||(x.title+" "+x.location+" "+x.type).toLowerCase().includes(term)) &&
   (!type||x.type===type) &&
   (!max||x.price<=max)
 );
 document.getElementById("grid").innerHTML=filtered.map(x=>`
 <article class="card">
   <div class="pic">${x.type==="Condo"?"🏢":x.type==="Lot"?"🌳":x.type==="Commercial"?"🏬":"🏠"}</div>
   <div class="info">
    <span class="tag">${x.type}</span>
    <h3>${x.title}</h3>
    <div class="location">📍 ${x.location}</div>
    <div class="price">${money(x.price)}</div>
    <div class="meta">${x.bedrooms?`🛏 ${x.bedrooms}`:""} ${x.bathrooms?`🚿 ${x.bathrooms}`:""} ${x.verified?"✓ Verified seller":""}</div>
    <div class="actions">
      <button onclick="details(${x.id})">View</button>
      <button class="fav" onclick="favorite(${x.id})">${favorites.includes(x.id)?"❤️ Saved":"♡ Save"}</button>
    </div>
   </div>
 </article>`).join("") || "<p>No properties found.</p>";
}
function details(id){
 const x=listings.find(v=>v.id===id);
 document.getElementById("modalBody").innerHTML=`<p class="eyebrow">${x.type}</p><h2>${x.title}</h2><p>📍 ${x.location}</p><h2>${money(x.price)}</h2><p>${x.bedrooms?"🛏 "+x.bedrooms+" bedrooms · ":""}${x.bathrooms?"🚿 "+x.bathrooms+" bathrooms":"Property listing"}</p><p>${x.verified?"✅ Seller marked as verified by the marketplace.":"Seller verification pending."}</p><button class="submit" onclick="alert('Contact feature will connect to the seller messaging system in the backend version.')">Contact Seller</button>`;
 document.getElementById("modal").classList.remove("hidden");
}
function favorite(id){
 favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];
 localStorage.setItem("bahayFavorites",JSON.stringify(favorites)); render();
}
function showFavorites(){render(listings.filter(x=>favorites.includes(x.id)))}
function openPost(){
 document.getElementById("modalBody").innerHTML=`<h2>Post a Property</h2><input id="pTitle" placeholder="Property title"><select id="pType"><option>House & Lot</option><option>Condo</option><option>Lot</option><option>Commercial</option></select><input id="pLocation" placeholder="City / Province"><input id="pPrice" type="number" placeholder="Price in pesos"><textarea id="pDesc" placeholder="Property description"></textarea><button class="submit" onclick="submitPost()">Submit Listing</button>`;
 document.getElementById("modal").classList.remove("hidden");
}
function submitPost(){
 const title=document.getElementById("pTitle").value.trim();
 const location=document.getElementById("pLocation").value.trim();
 const price=Number(document.getElementById("pPrice").value);
 if(!title||!location||!price){alert("Please complete the title, location and price.");return}
 listings.unshift({id:Date.now(),type:document.getElementById("pType").value,title,location,price,bedrooms:0,bathrooms:0,verified:false});
 closeModal();render();alert("Listing added to this demo marketplace. Backend publishing will be enabled after deployment.");
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
render();
